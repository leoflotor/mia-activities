branch(nb, [_, _, _, _, co/p, _]).
branch(b, [_, _, _, _, co/n, _]).
branch(nb, [_, _, ff/a, cr/n, co/a, _]).
branch(b, [_, _, ff/n, cr/n, co/a, _]).
branch(nb, [_, _, _, cr/p, co/a, _]).
branch(nb, [_, _, _, cr/a, co/a, _]).
